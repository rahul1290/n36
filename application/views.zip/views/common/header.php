<head>

	<title>NewsPrk</title>
	<!-- META -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!--::::: FABICON ICON :::::::-->
	<link rel="icon" href="<?php echo base_url('assets/img/icon/fabicon.png'); ?>">
	<!--::::: ALL CSS FILES :::::::-->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/plugins/bootstrap.min.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/plugins/animate.min.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/plugins/fontawesome.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/plugins/modal-video.min.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/plugins/owl.carousel.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/plugins/slick.css'); ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/css/plugins/stellarnav.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/theme.css'); ?>">
    

    <script src="<?php echo base_url('assets/js/plugins/jquery.2.1.0.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/bootstrap.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/jquery.nav.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/jquery.waypoints.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/jquery-modal-video.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/owl.carousel.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/popper.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/circle-progress.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/slick.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/stellarnav.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/plugins/wow.min.js'); ?>"></script>
	<script src="<?php echo base_url('assets/js/main.js'); ?>"></script>
</head>
<input type="hidden" name="baseUrl" id="baseUrl" value="<?php echo base_url(); ?>" />