<!DOCTYPE html>
<html lang="en">
    
    <?php if(isset($header)){ print_r($header); }?>

    <?php if(isset($body)){ print_r($body); }?>

</html>