<div class="logo_area white_bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 align-self-center">
					<div class="logo">
						<a href="<?php echo base_url(); ?>">
							<img src="<?php echo base_url('assets/img/logo/logo.png'); ?>" alt="image">
						</a>
					</div>
				</div>
				<div class="col-lg-8 align-self-center">
					<div class="banner1">
						<a href="#">
							<img src="<?php echo base_url('assets/img/bg/banner1.png'); ?>" alt="">
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>