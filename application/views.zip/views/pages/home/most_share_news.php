<div class="col-lg-4">
					<div class="row">
						<div class="col-lg-6 col-lg-12">
							<!--:::::: POST TYPE 4 START :::::::-->
							<div class="widget mb30">
								<h2 class="widget-title">Most share</h2>
								<div class="widget4_carousel owl-carousel nav_style1">
									<!--CAROUSEL START-->
									<div class="carousel_items">
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>1</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Nancy zhang a chinese busy woman and dhaka</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>2</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Harbour amid a Slowen down in singer city</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>3</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Cheap smartphone sensor could help you old food safe</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>4</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Nancy zhang a chinese busy woman and dhaka</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>5</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">The secret to moving this ancient sphinx screening</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
									</div>
									<div class="carousel_items">
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>1</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Nancy zhang a chinese busy woman and dhaka</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>2</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Harbour amid a Slowen down in singer city</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>3</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Cheap smartphone sensor could help you old food safe</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>4</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Nancy zhang a chinese busy woman and dhaka</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="single_post widgets_small widgets_type4">
											<div class="post_img number">
												<h2>5</h2>
											</div>
											<div class="single_post_text">
												<div class="meta2">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">The secret to moving this ancient sphinx screening</a></h4>
												<ul class="inline socail_share">
													<li>	<a href="#"><i class="fab fa-twitter"></i>2.2K</a>
													</li>
													<li>	<a href="#"><i class="fab fa-facebook-f"></i>2.2K</a>
													</li>
												</ul>
												<div class="space-15"></div>
												<div class="border_black"></div>
											</div>
										</div>
										<div class="space-15"></div>
									</div>
								</div>
								<!--CAROUSEL END-->
							</div>
							<!--:::::: POST TYPE 4 END :::::::-->
						</div>