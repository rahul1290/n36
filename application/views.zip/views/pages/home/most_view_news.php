<div class="col-md-12 col-lg-4">
<div class="follow_box widget mb30 mt-md-60">
					<h2 class="widget-title">Follow Us</h2>
					<div class="social_shares">
						<a class="single_social social_facebook" href="#">	<span class="follow_icon"><i class="fab fa-facebook-f"></i></span>
							34,456 <span class="icon_text">Fans</span>
						</a>
						<a class="single_social social_twitter" href="#">	<span class="follow_icon"><i class="fab fa-twitter"></i></span>
							34,456 <span class="icon_text">Followers</span>
						</a>
						<a class="single_social social_youtube" href="#">	<span class="follow_icon"><i class="fab fa-youtube"></i></span>
							34,456 <span class="icon_text">Subscribers</span>
						</a>
						<a class="single_social social_instagram" href="#">	<span class="follow_icon"><i class="fab fa-instagram"></i></span>
							34,456 <span class="icon_text">Followers</span>
						</a>
						<a class="single_social social_vimeo" href="#">	<span class="follow_icon"><i class="fab fa-vimeo-v"></i></span>
							34,456 <span class="icon_text">Followers</span>
						</a>
						<a class="single_social social_medium" href="#">	<span class="follow_icon"><i class="fab fa-medium-m"></i></span>
							34,456 <span class="icon_text">Followers</span>
						</a>
					</div>
				</div>
<!--:::::: POST TYPE 2 START :::::::-->
				<div class="widget tab_widgets mb30">
					<h2 class="widget-title">Most View</h2>
					<div class="post_type2_carousel owl-carousel nav_style1">
						<!--CAROUSEL START-->
						<div class="single_post2_carousel">
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm1.jpg" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Nancy zhang a chinese busy woman and dhaka</a></h4>
								</div>
								<div class="type8_count">
									<h2>1</h2>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm2.jpg" alt="">
									</div>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">The billionaire Philan thropist read to learn</a></h4>
								</div>
								<div class="type8_count">
									<h2>2</h2>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm3.jpg" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Cheap smartphone sensor could help you</a></h4>
								</div>
								<div class="type8_count">
									<h2>3</h2>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm4.jpg" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Class property employ ancho red multi</a></h4>
								</div>
								<div class="type8_count">
									<h2>4</h2>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm5.jpg" alt="">
									</div>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Best garden wing supplies for the horticu</a></h4>
								</div>
								<div class="type8_count">
									<h2>5</h2>
								</div>
							</div>
							<div class="space-15 ldnane"></div>
							<div class="border_black ldnane"></div>
							<div class="space-15 ldnane"></div>
							<div class="single_post widgets_small type8 ldnane">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/blog/blog_small3.jpg" alt="">
									</div>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Ratiffe to be Director of nation talent Trump</a></h4>
								</div>
								<div class="type8_count">
									<h2>6</h2>
								</div>
							</div>
						</div>
						<div class="single_post2_carousel">
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm1.jpg" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Nancy zhang a chinese busy woman and dhaka</a></h4>
								</div>
								<div class="type8_count">
									<h2>1</h2>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm2.jpg" alt="">
									</div>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">The billionaire Philan thropist read to learn</a></h4>
								</div>
								<div class="type8_count">
									<h2>2</h2>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm3.jpg" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Cheap smartphone sensor could help you</a></h4>
								</div>
								<div class="type8_count">
									<h2>3</h2>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm4.jpg" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Class property employ ancho red multi</a></h4>
								</div>
								<div class="type8_count">
									<h2>4</h2>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
							<div class="single_post widgets_small type8">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/most_view/mostsm5.jpg" alt="">
									</div>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Best garden wing supplies for the horticu</a></h4>
								</div>
								<div class="type8_count">
									<h2>5</h2>
								</div>
							</div>
							<div class="space-15 ldnane"></div>
							<div class="border_black ldnane"></div>
							<div class="space-15 ldnane"></div>
							<div class="single_post widgets_small type8 ldnane">
								<div class="post_img">
									<div class="img_wrap">
										<img src="assets/img/blog/blog_small3.jpg" alt="">
									</div>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Ratiffe to be Director of nation talent Trump</a></h4>
								</div>
								<div class="type8_count">
									<h2>6</h2>
								</div>
							</div>
						</div>
					</div>
					<!--CAROUSEL END-->
				</div>
</div>				