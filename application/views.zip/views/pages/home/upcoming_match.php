<div class="col-lg-6 col-lg-12">
							<!--:::::: POST TYPE 13 START:::::::-->
							<div class="widget upcomming_macth mb30">
								<div class="row">
									<div class="col-8 align-self-center">
										<h2 class="widget-title">Upcoming Matches</h2>
									</div>
									<div class="col-4 text-right align-self-center">	<a href="#" class="see_all mb20">See All</a>
									</div>
								</div>
								<div class="single_post post_type13 widgets_small">
									<div class="post_img">
										<a href="#">
											<img src="assets/img/flag/match1.png" alt="">
										</a>
									</div>
									<div class="single_post_text">
										<h4><a href="#" class="playing_teams">Germany <span>VS &nbsp;</span>France</a></h4>
										<p class="meta macth_meta">Tomorrow &nbsp;|&nbsp;<span> M22:30 (CST) </span> &nbsp;</p>
									</div>
									<div class="circle_match_time">
										<div class="first_circle circle"></div>
									</div>
								</div>
								<div class="space-10"></div>
								<div class="border_black"></div>
								<div class="space-10"></div>
								<div class="single_post post_type13 widgets_small">
									<div class="post_img">
										<a href="#">
											<img src="assets/img/flag/match2.png" alt="">
										</a>
									</div>
									<div class="single_post_text">
										<h4><a href="#" class="playing_teams">Spain <span>VS &nbsp;</span>Portugal</a></h4>
										<p class="meta macth_meta">Tomorrow&nbsp;|&nbsp;<span> M22:30 (CST) </span> &nbsp;</p>
									</div>
									<div class="circle_match_time">
										<div class="second_circle circle"></div>
									</div>
								</div>
								<div class="space-10"></div>
								<div class="border_black"></div>
								<div class="space-10"></div>
								<div class="single_post post_type13 widgets_small">
									<div class="post_img">
										<a href="#">
											<img src="assets/img/flag/match3.png" alt="">
										</a>
									</div>
									<div class="single_post_text">
										<h4><a href="#" class="playing_teams">Russia <span>VS &nbsp;</span>Italy</a></h4>
										<p class="meta macth_meta">Tomorrow&nbsp;|&nbsp;<span> M22:30 (CST) </span> &nbsp;</p>
									</div>
									<div class="circle_match_time">
										<div class="third_circle circle"></div>
									</div>
								</div>
								<div class="space-10"></div>
								<div class="border_black"></div>
								<div class="space-10"></div>
								<div class="single_post post_type13 widgets_small">
									<div class="post_img">
										<a href="#">
											<img src="assets/img/flag/match4.png" alt="">
										</a>
									</div>
									<div class="single_post_text">
										<h4><a href="#" class="playing_teams">Croatia <span>VS &nbsp;</span>England</a></h4>
										<p class="meta macth_meta">Tomorrow&nbsp;|&nbsp;<span> M22:30 (CST) </span> &nbsp;</p>
									</div>
									<div class="circle_match_time">
										<div class="fourth_circle circle"></div>
									</div>
								</div>
								<div class="space-10"></div>
								<div class="border_black"></div>
								<div class="space-10"></div>
								<div class="single_post post_type13 widgets_small">
									<div class="post_img">
										<a href="#">
											<img src="assets/img/flag/match5.png" alt="">
										</a>
									</div>
									<div class="single_post_text">
										<h4><a href="#" class="playing_teams">Germany <span>VS &nbsp;</span>France</a></h4>
										<p class="meta macth_meta">Tomorrow&nbsp;|&nbsp;<span> M22:30 (CST) </span> &nbsp;</p>
									</div>
									<div class="circle_match_time">
										<div class="fifth_circle circle"></div>
									</div>
								</div>
							</div>
							<!--:::::: POST TYPE 13 END:::::::-->
						</div>