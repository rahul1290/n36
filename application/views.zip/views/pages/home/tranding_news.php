<!--::::: TRANDING CAROUSEL AREA START :::::::-->
<div class="container">
		<div class="row">
			<div class="col-lg-6 col-lg-8">
				<h2 class="widget-title">Trending News</h2>
				<div class="carousel_post2_type3 nav_style1 owl-carousel">
					<!--CAROUSEL START-->
					<div class="single_post post_type3">
						<div class="post_img">
							<div class="img_wrap">
								<img src="assets/img/trending/trendbig1.jpg" alt="">
							</div>	<span class="tranding">
								<i class="fas fa-bolt"></i>
							</span>
						</div>
						<div class="single_post_text">
							<div class="meta3">	<a href="#">TECHNOLOGY</a>
								<a href="#">March 26, 2020</a>
							</div>
							<h4><a href="post1.html">There may be no consoles in the future ea exec says</a></h4>
							<div class="space-10"></div>
							<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
						</div>
					</div>
					<div class="single_post post_type3">
						<div class="post_img">
							<div class="img_wrap">
								<img src="assets/img/trending/trendbig2.jpg" alt="">
							</div>
						</div>
						<div class="single_post_text">
							<div class="meta3">	<a href="#">TECHNOLOGY</a>
								<a href="#">March 26, 2020</a>
							</div>
							<h4><a href="post1.html">Japan’s virus success has puzzled the world. Is its luck running out?</a></h4>
							<div class="space-10"></div>
							<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
						</div>
					</div>
					<div class="single_post post_type3">
						<div class="post_img">
							<div class="img_wrap">
								<img src="assets/img/trending/trendbig2.jpg" alt="">
							</div>
						</div>
						<div class="single_post_text">
							<div class="meta3">	<a href="#">TECHNOLOGY</a>
								<a href="#">March 26, 2020</a>
							</div>
							<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
							<div class="space-10"></div>
							<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
						</div>
					</div>
				</div>
				<div class="border_black"></div>
				<div class="space-30"></div>
				<div class="row">
					<div class="col-lg-6">
						<div class="single_post widgets_small">
							<div class="post_img">
								<div class="img_wrap">
									<img src="assets/img/trending/transm4.jpg" alt="">
								</div>	<span class="tranding">
									<i class="fas fa-bolt"></i>
								</span>
							</div>
							<div class="single_post_text">
								<div class="meta2">	<a href="#">TECHNOLOGY</a>
									<a href="#">March 26, 2020</a>
								</div>
								<h4><a href="post1.html">Nancy Zhang a Chinese busy woman and Dhaka</a></h4>
							</div>
						</div>
						<div class="space-15"></div>
						<div class="border_black"></div>
						<div class="space-15"></div>
						<div class="single_post widgets_small">
							<div class="post_img">
								<div class="img_wrap">
									<img src="assets/img/trending/transm5.jpg" alt="">
								</div>	<span class="tranding">
									<i class="fas fa-bolt"></i>
								</span>
							</div>
							<div class="single_post_text">
								<div class="meta2">	<a href="#">TECHNOLOGY</a>
									<a href="#">March 26, 2020</a>
								</div>
								<h4><a href="post1.html">U.S. Response subash says he will label regions by risk of…</a></h4>
							</div>
						</div>
						<div class="space-15"></div>
						<div class="border_black"></div>
						<div class="space-15"></div>
						<div class="single_post widgets_small">
							<div class="post_img">
								<div class="img_wrap">
									<img src="assets/img/trending/transm6.jpg" alt="">
								</div>	<span class="tranding">
									<i class="fas fa-bolt"></i>
								</span>
							</div>
							<div class="single_post_text">
								<div class="meta2">	<a href="#">TECHNOLOGY</a>
									<a href="#">March 26, 2020</a>
								</div>
								<h4><a href="post1.html">Venezuela elan govt and opposit the property collect</a></h4>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="single_post widgets_small">
							<div class="post_img">
								<div class="img_wrap">
									<img src="assets/img/trending/transm1.jpg" alt="">
								</div>	<span class="tranding">
									<i class="fas fa-bolt"></i>
								</span>
							</div>
							<div class="single_post_text">
								<div class="meta2">	<a href="#">TECHNOLOGY</a>
									<a href="#">March 26, 2020</a>
								</div>
								<h4><a href="post1.html">Nancy Zhang a Chinese busy woman and Dhaka</a></h4>
							</div>
						</div>
						<div class="space-15"></div>
						<div class="border_black"></div>
						<div class="space-15"></div>
						<div class="single_post widgets_small">
							<div class="post_img">
								<div class="img_wrap">
									<img src="assets/img/trending/transm2.jpg" alt="">
								</div>	<span class="tranding">
									<i class="fas fa-bolt"></i>
								</span>
							</div>
							<div class="single_post_text">
								<div class="meta2">	<a href="#">TECHNOLOGY</a>
									<a href="#">March 26, 2020</a>
								</div>
								<h4><a href="post1.html">U.S. Response subash says he will label regions by risk of…</a></h4>
							</div>
						</div>
						<div class="space-15"></div>
						<div class="border_black"></div>
						<div class="space-15"></div>
						<div class="single_post widgets_small">
							<div class="post_img">
								<div class="img_wrap">
									<img src="assets/img/trending/transm6.jpg" alt="">
								</div>	<span class="tranding">
									<i class="fas fa-bolt"></i>
								</span>
							</div>
							<div class="single_post_text">
								<div class="meta2">	<a href="#">TECHNOLOGY</a>
									<a href="#">March 26, 2020</a>
								</div>
								<h4><a href="post1.html">Venezuela elan govt and opposit the property collect</a></h4>
							</div>
						</div>
					</div>
				</div>
			</div>
				
			<?php if(isset($most_view_news)){ print_r($most_view_news); }?>
			
		</div>
	</div>
	<!--::::: TRANDING CAROUSEL AREA END :::::::-->