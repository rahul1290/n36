<div class="col-lg-8">
					<div class="row">
						<div class="col-12">
							<div class="heading">
								<h2 class="widget-title">Entertrainment News</h2>
							</div>
						</div>
					</div>
					<div class="entertrainment_carousel mb30">
						<!--CAROUSEL START-->
						<div class="entertrainment_item">
							<div class="row justify-content-center">
								<div class="col-md-6">
									<div class="single_post post_type3 mb30">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/entertrainment/enter1.jpg" alt="">
												</a>
											</div>
										</div>
										<div class="single_post_text">
											<div class="meta3">	<a href="#">TECHNOLOGY</a>
												<a href="#">March 26, 2020</a>
											</div>
											<h4><a href="post1.html">There may be no consoles in the future ea exec says</a></h4>
											<div class="space-10"></div>
											<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="single_post post_type3 mb30">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/entertrainment/enter2.jpg" alt="">
												</a>
											</div>
										</div>
										<div class="single_post_text">
											<div class="meta3">	<a href="#">TECHNOLOGY</a>
												<a href="#">March 26, 2020</a>
											</div>
											<h4><a href="post1.html">There may be no consoles in the future ea exec says</a></h4>
											<div class="space-10"></div>
											<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="single_post post_type3 mb30">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/entertrainment/enter3.jpg" alt="">
												</a>
											</div>
										</div>
										<div class="single_post_text">
											<div class="meta3">	<a href="#">TECHNOLOGY</a>
												<a href="#">March 26, 2020</a>
											</div>
											<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
											<div class="space-10"></div>
											<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="single_post post_type3 mb30">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/entertrainment/enter4.jpg" alt="">
												</a>
											</div>
										</div>
										<div class="single_post_text">
											<div class="meta3">	<a href="#">TECHNOLOGY</a>
												<a href="#">March 26, 2020</a>
											</div>
											<h4><a href="post1.html">There may be no consoles in the future ea exec says</a></h4>
											<div class="space-10"></div>
											<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php if(isset($sports_news)){ print_r($sports_news); }?>
					<?php if(isset($business_news)){ print_r($business_news); }?>
				</div>