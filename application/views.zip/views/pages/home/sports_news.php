<!--CAROUSEL END-->
					<div class="row">
						<div class="col-12">
							<div class="sports">
								<div class="row">
									<div class="col-12">
										<div class="heading">
											<h2 class="widget-title">Sports News</h2>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="single_post post_type3 mb30">
											<div class="post_img">
												<a href="#">
													<img src="assets/img/sports/sportsbig1.jpg" alt="">
												</a>	<span class="tranding">
													<i class="fas fa-bolt"></i>
												</span>
											</div>
											<div class="single_post_text">
												<div class="meta3">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
												<div class="space-10"></div>
												<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
												<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="sports_carousel owl-carousel nav_style1">
											<!--CAROUSEL START-->
											<div class="sports_carousel_item">
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#">
																<img src="assets/img/sports/sports2.jpg" alt="">
															</a>
														</div>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
													</div>
												</div>
												<div class="space-15"></div>
												<div class="border_black"></div>
												<div class="space-15"></div>
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#">
																<img src="assets/img/sports/sports3.jpg" alt="">
															</a>
														</div>	<span class="tranding">
															<i class="fas fa-bolt"></i>
														</span>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4>
															
														<a href="post1.html">Copa America: Luis Suarez from devastated US</a>

														</h4>	
													</div>
												</div>
												<div class="space-15"></div>
												<div class="border_black"></div>
												<div class="space-15"></div>
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#">
																<img src="assets/img/sports/sports4.jpg" alt="">
															</a>
														</div>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
													</div>
												</div>
												<div class="space-15"></div>
												<div class="border_black"></div>
												<div class="space-15"></div>
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#">
																<img src="assets/img/sports/sports5.jpg" alt="">
															</a>
														</div>	<span class="tranding">
															<i class="fas fa-bolt"></i>
														</span>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
													</div>
												</div>
												<div class="space-15"></div>
												<div class="border_black"></div>
												<div class="space-15"></div>
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#">
																<img src="assets/img/sports/sports6.jpg" alt="">
															</a>
														</div>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
													</div>
												</div>
											</div>
											<div class="sports_carousel_item">
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#">
																<img src="assets/img/blog/blog_small1.jpg" alt="">
															</a>
														</div>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
													</div>
												</div>
												<div class="space-15"></div>
												<div class="border_black"></div>
												<div class="space-15"></div>
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#">
																<img src="assets/img/blog/blog_small2.jpg" alt="">
															</a>
														</div>	<span class="tranding">
															<i class="fas fa-bolt"></i>
														</span>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4>
															
														<a href="post1.html">Copa America: Luis Suarez from devastated US</a>

														</h4>	
													</div>
												</div>
												<div class="space-15"></div>
												<div class="border_black"></div>
												<div class="space-15"></div>
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#">
																<img src="assets/img/blog/blog_small3.jpg" alt="">
															</a>
														</div>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
													</div>
												</div>
												<div class="space-15"></div>
												<div class="border_black"></div>
												<div class="space-15"></div>
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#"><img src="assets/img/blog/blog_small4.jpg" alt=""></a>
														</div>	
														<span class="tranding">
															<i class="fas fa-bolt"></i>
														</span>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
													</div>
												</div>
												<div class="space-15"></div>
												<div class="border_black"></div>
												<div class="space-15"></div>
												<div class="single_post widgets_small">
													<div class="post_img">
														<div class="img_wrap">
															<a href="#">
																<img src="assets/img/blog/blog_small5.jpg" alt="">
															</a>
														</div>
													</div>
													<div class="single_post_text">
														<div class="meta2">	<a href="#">TECHNOLOGY</a>
															<a href="#">March 26, 2020</a>
														</div>
														<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
													</div>
												</div>
											</div>
										</div>
										<!--CAROUSEL END-->
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="banner_area mt50 mb60 xs-mt60">
						<a href="#">
							<img src="assets/img/bg/banner1.png" alt="">
						</a>
					</div>