<div class="video_posts pt30 half_bg60">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="heading white">
						<h2 class="widget-title">Video News</h2>
					</div>
				</div>
			</div>
			<div class="space-50"></div>
			<div class="viceo_posts_wrap">
				<div class="row">
					<div class="col-lg-8">
						<div class="single_post post_type3 post_type11 margintop-60- xs-mb30">
							<div class="post_img">
								<div class="img_wrap">
									<a href="#" class="play_btn">
										<img src="assets/img/video/video1.jpg" alt="">
									</a>
								</div>	<a href="#" class="youtube_middle"><i class="fab fa-youtube"></i></a>
							</div>
							<div class="single_post_text padding30 fourth_bg">
								<div class="meta3">	<a href="#">TECHNOLOGY</a>
									<a href="#">March 26, 2020</a>
								</div>
								<h4><a href="post1.html">Riots Report Shows London Needs To Maintain Police Numbers, Says Mayor</a></h4>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="popular_carousel_area mb30 md-mt-30">
							<h2 class="widget-title">Popular Posts</h2>
							<div class="popular_carousel owl-carousel nav_style1">
								<!--CAROUSEL START-->
								<div class="popular_items">
									<div class="single_post type10 widgets_small mb15">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm1.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												1
											</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">The property complete with a 30 seat screen room.</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
									<div class="single_post type10 widgets_small mb15">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm2.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												2
											</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">Cheap smartphone sensor could help you old.</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
									<div class="single_post type10 widgets_small mb15">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm3.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												3
											</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">Harbour amid a Slowen the down in singer city</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
									<div class="single_post type10 widgets_small mb15">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm4.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												4
											</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">The secret to moving this from sphinx screening</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
									<div class="single_post type10 widgets_small ldnane">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm5.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												5</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">The secret to moving this from sphinx screening</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
								</div>
								<div class="popular_items">
									<div class="single_post type10 widgets_small mb15">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm1.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												1
											</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">The property complete with a 30 seat screen room.</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
									<div class="single_post type10 widgets_small mb15">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm2.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												2
											</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">Cheap smartphone sensor could help you old.</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
									<div class="single_post type10 widgets_small mb15">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm3.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												3
											</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">Harbour amid a Slowen the down in singer city</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
									<div class="single_post type10 widgets_small mb15">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm4.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												4
											</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">The secret to moving this from sphinx screening</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
									<div class="single_post type10 widgets_small ldnane">
										<div class="post_img">
											<div class="img_wrap">
												<a href="#">
													<img src="assets/img/popular/popularsm5.jpg" alt="">
												</a>
											</div>	<span class="tranding tranding_border">
												5</span>
										</div>
										<div class="single_post_text">
											<h4><a href="post1.html">The secret to moving this from sphinx screening</a></h4>
											<div class="meta4">	<a href="#">TECHNOLOGY</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!--CAROUSEL END-->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>