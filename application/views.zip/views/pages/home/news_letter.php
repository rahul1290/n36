<div class="col-lg-6 col-lg-12">
							<div class="box widget news_letter mb30">
								<h2 class="widget-title">News Letter</h2>
								<p>Your email address will not be this published. Required fields are News Today.</p>
								<div class="space-20"></div>
								<div class="signup_form">
									<form action="index.html">
										<input class="signup" type="email" placeholder="Your email">
										<input type="button" class="cbtn" value="sign up">
									</form>
									<div class="space-10"></div>
									<p>We hate spam as much as you do</p>
								</div>
							</div>
						</div>