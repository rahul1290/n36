<body class="theme-1">
	<!--::::: TOP BAR START :::::::-->
	<?php if(isset($tranding_news)){ print_r($tranding_news); }?>
	<!--::::: TOP BAR END :::::::-->
	<div class="border_black"></div>
	<!--::::: LOGO AREA START  :::::::-->
	<?php if(isset($brand_logo)){ print_r($brand_logo); }?>
	<!--::::: LOGO AREA END :::::::-->
	
	<!--::::: MENU AREA START  :::::::-->
	<?php if(isset($topmenu)){ print_r($topmenu); }?>
	<!--::::: MENU AREA END :::::::-->
	<!--::::: INNER TABLE AREA START :::::::-->
	<div class="inner_table">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="bridcrumb">	<a href="#">Home</a> / Sports</div>
				</div>
			</div>
		</div>
	</div>
	<!--::::: INNER TABLE AREA END :::::::-->
	<!--::::: ARCHIVE AREA START :::::::-->
	<div class="archives padding-top-30">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-8">
					<div class="row">
						<div class="col-12 align-self-center">
							<div class="categories_title">
								<h5>Category: <a href="#">Sports</a></h5>
							</div>
						</div>
					</div>
					<div class="row justify-content-center">
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sports41.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sportsbig1.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sportsbig1.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sports41.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sports41.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sports41.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sports41.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sports41.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sports41.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="single_post post_type3 mb30">
								<div class="post_img">
									<a href="#">
										<img src="<?php echo base_url('assets/img/sports/sports41.jpg'); ?>" alt="">
									</a>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
									<div class="space-20"></div>	<a href="#" class="readmore">Read More</a>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="cpagination padding5050">
								<nav aria-label="Page navigation example">
									<ul class="pagination">
										<li class="page-item">
											<a class="page-link" href="#" aria-label="Previous"> <span aria-hidden="true"><i class="fas fa-caret-left"></i></span>
											</a>
										</li>
										<li class="page-item"><a class="page-link" href="#">1</a>
										</li>
										<li class="page-item"><a class="page-link" href="#">..</a>
										</li>
										<li class="page-item"><a class="page-link" href="#">5</a>
										</li>
										<li class="page-item">
											<a class="page-link" href="#" aria-label="Next"> <span aria-hidden="true"><i class="fas fa-caret-right"></i></span>
											</a>
										</li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-lg-4">
						<div class="widget_tab md-mt-30">
							<ul class="nav nav-tabs">
								<li><a class="active" data-toggle="tab" href="#post1">RELATED</a>
								</li>
								<li><a data-toggle="tab" href="#post2" class="">RELATED</a>
								</li>
								<li><a data-toggle="tab" href="#post3" class="">POPULAR</a>
								</li>
							</ul>
	
							<div class="tab-content">
								<div id="post1" class="tab-pane fade in active show">
									<div class="widget tab_widgets mb30">
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab1.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab2.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Nancy Zhang a Chinese busy woman and Dhaka</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab3.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">U.S. Response subash says he will label regions by risk of…</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab4.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Venezuela elan govt and opposit the property collect</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab5.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Cheap smartphone sensor could help you old food safe</a></h4>
											</div>
										</div>
									</div>
								</div>
								<div id="post2" class="tab-pane fade">
									<div class="widget tab_widgets mb30">
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab1.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab2.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Nancy Zhang a Chinese busy woman and Dhaka</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab3.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">U.S. Response subash says he will label regions by risk of…</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab4.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Venezuela elan govt and opposit the property collect</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab5.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Cheap smartphone sensor could help you old food safe</a></h4>
											</div>
										</div>
									</div>
								</div>
								<div id="post3" class="tab-pane fade">
									<div class="widget tab_widgets mb30">
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab1.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Copa America: Luis Suarez from devastated US</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab2.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Nancy Zhang a Chinese busy woman and Dhaka</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab3.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">U.S. Response subash says he will label regions by risk of…</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab4.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Venezuela elan govt and opposit the property collect</a></h4>
											</div>
										</div>
										<div class="space-15"></div>
										<div class="border_black"></div>
										<div class="space-15"></div>
										<div class="single_post widgets_small">
											<div class="post_img">
												<div class="img_wrap">
													<a href="#">
														<img src="<?php echo base_url('assets/img/header/widget/tab5.jpg'); ?>" alt="">
													</a>
												</div>
											</div>
											<div class="single_post_text">
												<div class="meta2 meta_separator1">	<a href="#">TECHNOLOGY</a>
													<a href="#">March 26, 2020</a>
												</div>
												<h4><a href="post1.html">Cheap smartphone sensor could help you old food safe</a></h4>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
	
	
						<div class="trending_widget mb30">
								<h2 class="widget-title">Tending News</h2>
							<div class="single_post post_type3">
								<div class="post_img">
									<div class="img_wrap">
										<img src="<?php echo base_url('assets/img/trending/trendbig1.jpg'); ?>" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta3">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">There may be no consoles in the future ea exec says</a></h4>
									<div class="space-10"></div>
									<p class="post-p">The property, complete with 30-seat screening from room, a 100-seat amphitheater and a swimming pond with sandy shower…</p>
								</div>
							</div>
	
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-30"></div>
							<div class="single_post widgets_small">
								<div class="post_img">
									<div class="img_wrap">
										<img src="<?php echo base_url('assets/img/trending/transm4.jpg'); ?>" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Nancy Zhang a Chinese busy woman and Dhaka</a></h4>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
							<div class="single_post widgets_small">
								<div class="post_img">
									<div class="img_wrap">
										<img src="<?php echo base_url('assets/img/trending/transm5.jpg'); ?>" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">U.S. Response subash says he will label regions by risk of…</a></h4>
								</div>
							</div>
							<div class="space-15"></div>
							<div class="border_black"></div>
							<div class="space-15"></div>
	
							<div class="single_post widgets_small">
								<div class="post_img">
									<div class="img_wrap">
										<img src="<?php echo base_url('assets/img/trending/transm6.jpg'); ?>" alt="">
									</div>	<span class="tranding">
										<i class="fas fa-bolt"></i>
									</span>
								</div>
								<div class="single_post_text">
									<div class="meta2">	<a href="#">TECHNOLOGY</a>
										<a href="#">March 26, 2020</a>
									</div>
									<h4><a href="post1.html">Venezuela elan govt and opposit the property collect</a></h4>
								</div>
							</div>
						</div>
						<!--:::::: POST TYPE 4 END :::::::-->
						
						<?php if(isset($news_letter)){ print_r($news_letter); }?>
							
						<div class="follow_box widget mb30">
							<h2 class="widget-title">Follow Us</h2>
							<div class="social_shares">
								<a class="single_social social_facebook" href="#">	<span class="follow_icon"><i class="fab fa-facebook-f"></i></span>
									34,456 <span class="icon_text">Fans</span>
								</a>
								<a class="single_social social_twitter" href="#">	<span class="follow_icon"><i class="fab fa-twitter"></i></span>
									34,456 <span class="icon_text">Followers</span>
								</a>
								<a class="single_social social_youtube" href="#">	<span class="follow_icon"><i class="fab fa-youtube"></i></span>
									34,456 <span class="icon_text">Subscribers</span>
								</a>
								<a class="single_social social_instagram" href="#">	<span class="follow_icon"><i class="fab fa-instagram"></i></span>
									34,456 <span class="icon_text">Followers</span>
								</a>
								<a class="single_social social_vimeo" href="#">	<span class="follow_icon"><i class="fab fa-vimeo-v"></i></span>
									34,456 <span class="icon_text">Followers</span>
								</a>
								<a class="single_social social_medium" href="#">	<span class="follow_icon"><i class="fab fa-medium-m"></i></span>
									34,456 <span class="icon_text">Followers</span>
								</a>
							</div>
						</div>
						<!--:::::: POST TYPE 2 END:::::::-->
						<div class="banner2 mb30">
							<a href="#">
								<img src="<?php echo base_url('assets/img/bg/sidebar-1.png'); ?>" alt="">
							</a>
						</div>
						<!--:::::: POST TYPE 4 START :::::::-->
					</div>
			</div>
		</div>
	</div>
	<!--::::: ARCHIVE AREA END :::::::-->
	<!--::::: BANNER AREA START :::::::-->
	<div class="padding5050 fourth_bg">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 m-auto">
					<div class="banner1">
						<a href="#">
							<img src="<?php echo base_url('assets/img/bg/banner1.png'); ?>" alt="">
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--::::: BANNER AREA END :::::::-->
	<!--::::: FOOTER AREA START :::::::-->
	<div class="footer footer_area1 primay_bg">
		<div class="container">
			<div class="cta">
				<div class="row">
					<div class="col-md-6 align-self-center">
						<div class="footer_logo logo">
							<a href="index.html">
								<img src="<?php echo base_url('assets/img/logo/footer_logo.png'); ?>" alt="logo">
							</a>
						</div>
						<div class="social2">
							<ul class="inline">
								<li><a href="#"><i class="fab fa-instagram"></i></a>
								</li>
								<li><a href="#"><i class="fab fa-facebook-f"></i></a>
								</li>
								<li><a href="#"><i class="fab fa-youtube"></i></a>
								</li>
								<li><a href="#"><i class="fab fa-instagram"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-md-6 col-lg-4 offset-lg-2 align-self-center">
						<div class="signup_form">
							<form action="index.html" method="post">
								<input class="signup" type="email" placeholder="Your email address">
								<input type="button" class="cbtn" value="sign up">
							</form>
							<p>We hate spam as much as you do</p>
						</div>
					</div>
				</div>
			</div>
			<div class="border_white"></div>
			<div class="space-40"></div>
			<div class="row justify-content-center">
				<div class="col-lg-8">
					<div class="row">
						<div class="col-sm-6 col-lg">
							<div class="single_footer_nav border_white_right">
								<h3 class="widget-title2">News categories</h3>
								<div class="row">
									<div class="col-lg-6">
										<ul>
											<li><a href="#">Politics</a>
											</li>
											<li><a href="#">Business</a>
											</li>
											<li><a href="#">TECHNOLOGY</a>
											</li>
											<li><a href="#">Science</a>
											</li>
											<li><a href="#">Health</a>
											</li>
											<li><a href="#">Sports</a>
											</li>
											<li><a href="#">Entertainment</a>
											</li>
										</ul>
									</div>
									<div class="col-lg-6">
										<ul>
											<li><a href="#">Education</a>
											</li>
											<li><a href="#">Obituaries</a>
											</li>
											<li><a href="#">Corrections</a>
											</li>
											<li><a href="#">Education</a>
											</li>
											<li><a href="#">Today’s Paper</a>
											</li>
											<li><a href="#">Corrections</a>
											</li>
											<li><a href="#">Foods</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-lg">
							<div class="single_footer_nav">
								<h3 class="widget-title2">Living</h3>
								<div class="row">
									<div class="col-lg-6">
										<ul>
											<li><a href="#">Crossword</a>
											</li>
											<li><a href="#">Food</a>
											</li>
											<li><a href="#">Automobiles</a>
											</li>
											<li><a href="#">Education</a>
											</li>
											<li><a href="#">Health</a>
											</li>
											<li><a href="#">Magazine</a>
											</li>
											<li><a href="#">Weddings</a>
											</li>
										</ul>
									</div>
									<div class="col-lg-6">
										<ul>
											<li><a href="#">Classifieds</a>
											</li>
											<li><a href="#">Photographies</a>
											</li>
											<li><a href="#">NYT Store</a>
											</li>
											<li><a href="#">Journalisms</a>
											</li>
											<li><a href="#">Public Editor</a>
											</li>
											<li><a href="#">Tools & Services</a>
											</li>
											<li><a href="#">My Account</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="space-40"></div>
					<div class="border_white"></div>
					<div class="space-40"></div>
					<div class="row">
						<div class="col-sm-6 col-lg-5">
							<div class="single_footer_nav border_white_right">
								<h3 class="widget-title2">Opinion</h3>
								<div class="row">
									<div class="col-lg-6">
										<ul>
											<li><a href="#">Today’s Opinion</a>
											</li>
											<li><a href="#">Op-Ed Contributing</a>
											</li>
											<li><a href="#">Contributing Writers</a>
											</li>
											<li><a href="#">Business News</a>
											</li>
											<li><a href="#">Collections</a>
											</li>
											<li><a href="#">Today’s Paper</a>
											</li>
											<li><a href="#">Saturday Review</a>
											</li>
											<li><a href="#">Product Review</a>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-lg-7">
							<div class="twitter_feeds">
								<h3 class="widget-title2">Twitter feed</h3>
								<div class="single_twitter_feed border_white_bottom">
									<div class="twitter_feed_icon">	<i class="fab fa-twitter"></i>
									</div>
									<h6>Cyber Monday Sale, Save 33% on Jannah theme during our year-end Sale, Purchase a new license for your next project… <span>@newspark #TECHNOLOGY https://dribbble.com/subash_chandra</span></h6>
									<p>March 26, 2020</p>
								</div>
								<div class="single_twitter_feed">
									<div class="twitter_feed_icon">	<i class="fab fa-twitter"></i>
									</div>
									<h6>Cyber Monday Sale, Save 33% on Jannah theme during our year-end Sale, Purchase a new license for your next project… <span>@newspark #TECHNOLOGY https://dribbble.com/subash_chandra</span></h6>
									<p>March 26, 2020</p>
								</div>
								<div class="single_twitter_feed">
									<div class="twitter_feed_icon">	<i class="fab fa-twitter"></i>
									</div>
									<h6>Cyber Monday Sale, Save 33% on Jannah theme during our year-end Sale, Purchase a new license for your next project… <span>@newspark #TECHNOLOGY https://dribbble.com/subash_chandra</span></h6>
									<p>March 26, 2020</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="extra_newss border_white_left pl-4">
						<h3 class="widget-title2">More news</h3>
						<div class="single_extra_news border_white_bottom">
							<p>TECHNOLOGY <span> / March 26, 2020</span>
							</p>	<a href="#">Nancy zhang a chinese busy woman and dhaka</a>
							<span class="news_counter">1</span>
						</div>
						<div class="single_extra_news border_white_bottom">
							<p>TECHNOLOGY <span> / March 26, 2020</span>
							</p>	<a href="#">Nancy zhang a chinese busy woman and dhaka</a>
							<span class="news_counter">2</span>
						</div>
						<div class="single_extra_news border_white_bottom">
							<p>TECHNOLOGY <span> / March 26, 2020</span>
							</p>	<a href="#">Nancy zhang a chinese busy woman and dhaka</a>
							<span class="news_counter">3</span>
						</div>
						<div class="single_extra_news border_white_bottom">
							<p>TECHNOLOGY <span> / March 26, 2020</span>
							</p>	<a href="#">Nancy zhang a chinese busy woman and dhaka</a>
							<span class="news_counter">4</span>
						</div>
						<div class="single_extra_news">
							<p>TECHNOLOGY <span> / March 26, 2020</span>
							</p>	<a href="#">Nancy zhang a chinese busy woman and dhaka</a>
							<span class="news_counter">5</span>
						</div>
						<div class="space-40"></div>
						<div class="border_white_bottom"></div>
						<div class="space-40"></div>
						<div class="footer_contact">
							<h3 class="widget-title2">Newspark news services</h3>
							<div class="single_fcontact">
								<div class="fcicon">
									<img src="<?php echo base_url('assets/img/icon/mobile.png'); ?>" alt="">
								</div>	<a href="#">On your mobile</a>
							</div>
							<div class="single_fcontact">
								<div class="fcicon">
									<img src="<?php echo base_url('assets/img/icon/speacker.png'); ?>" alt="">
								</div>	<a href="#">On smart speakers</a>
							</div>
							<div class="single_fcontact">
								<div class="fcicon">
									<img src="<?php echo base_url('assets/img/icon/evelope.png'); ?>" alt="">
								</div>	<a href="#">Contact Newspark news</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 align-self-center">
						<p>&copy; Copyright 2020, All Rights Reserved</p>
					</div>
					<div class="col-lg-6 align-self-center">
						<div class="copyright_menus text-right">
							<div class="language"></div>
							<div class="copyright_menu inline">
								<ul>
									<li><a href="#">About</a>
									</li>
									<li><a href="#">Advertise</a>
									</li>
									<li><a href="#">Privacy & Policy</a>
									</li>
									<li><a href="#">Contact Us</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	